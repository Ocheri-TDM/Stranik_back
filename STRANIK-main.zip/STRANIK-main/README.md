#STRANIK

https://alexseylast.github.io/STRANIK/

https://www.figma.com/design/NWJwkAnKvGKkcGRRjEv4ZA/Stranik?node-id=0-1&t=IzCJmpWHT27rNajK-1

